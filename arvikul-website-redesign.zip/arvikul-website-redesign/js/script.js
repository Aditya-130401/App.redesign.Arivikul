/* =========================================================
   ArviKul Technologies – front-end behaviour (vanilla ES6+)
   1 Theme switching + localStorage   2 Mobile navigation
   3 Smooth scroll + back-to-top      4 Scroll reveal
   5 Logo fallback                    6 Form validation
   ========================================================= */
(() => {
  'use strict';

  const root = document.documentElement;
  const THEME_KEY = 'arvikul-theme';
  const THEMES = ['light', 'dark', 'blue'];
  const THEME_COLORS = { light: '#f4f8ff', dark: '#070d1c', blue: '#0d3b91' };
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const $ = (sel, scope = document) => scope.querySelector(sel);
  const $$ = (sel, scope = document) => Array.from(scope.querySelectorAll(sel));

  /* ---------- 1. Theme (applied immediately to avoid a flash) ---------- */
  const storage = {
    get(key) { try { return window.localStorage.getItem(key); } catch (e) { return null; } },
    set(key, value) { try { window.localStorage.setItem(key, value); } catch (e) { /* storage unavailable */ } }
  };

  function applyTheme(theme, persist) {
    if (!THEMES.includes(theme)) theme = 'light';
    root.setAttribute('data-theme', theme);
    const meta = $('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', THEME_COLORS[theme]);
    $$('[data-theme-btn]').forEach((btn) => btn.setAttribute('aria-pressed', String(btn.dataset.themeBtn === theme)));
    if (persist) storage.set(THEME_KEY, theme);
  }

  function initialTheme() {
    const saved = storage.get(THEME_KEY);
    if (THEMES.includes(saved)) return saved;
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  root.classList.add('js');
  applyTheme(initialTheme(), false);

  function initTheme() {
    applyTheme(root.getAttribute('data-theme'), false);
    $$('[data-theme-btn]').forEach((btn) =>
      btn.addEventListener('click', () => applyTheme(btn.dataset.themeBtn, true))
    );
  }

  /* ---------- 2. Mobile navigation ---------- */
  function initNav() {
    const toggle = $('.nav-toggle');
    const nav = $('#site-nav');
    if (!toggle || !nav) return;

    const setOpen = (open, returnFocus) => {
      nav.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
      document.body.classList.toggle('nav-open', open);
      if (!open && returnFocus) toggle.focus();
    };
    const isOpen = () => toggle.getAttribute('aria-expanded') === 'true';

    toggle.addEventListener('click', () => setOpen(!isOpen()));
    nav.addEventListener('click', (e) => { if (e.target.closest('a')) setOpen(false); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && isOpen()) setOpen(false, true); });
    document.addEventListener('click', (e) => { if (isOpen() && !e.target.closest('.site-header')) setOpen(false); });
    const desktop = window.matchMedia('(min-width: 900px)');
    const onChange = (e) => { if (e.matches) setOpen(false); };
    if (desktop.addEventListener) desktop.addEventListener('change', onChange); else desktop.addListener(onChange);
  }

  /* ---------- 3. Scroll behaviour ---------- */
  function initScroll() {
    const header = $('.site-header');
    const topBtn = $('.back-to-top');
    let ticking = false;

    const update = () => {
      const y = window.scrollY || window.pageYOffset;
      if (header) header.classList.toggle('is-scrolled', y > 8);
      if (topBtn) topBtn.classList.toggle('is-visible', y > 500);
      ticking = false;
    };
    window.addEventListener('scroll', () => {
      if (!ticking) { ticking = true; window.requestAnimationFrame(update); }
    }, { passive: true });
    update();

    if (topBtn) {
      topBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: reduceMotion.matches ? 'auto' : 'smooth' });
        const skip = $('.skip-link');
        if (skip) { skip.focus({ preventScroll: true }); skip.blur(); }
      });
    }

    // Smooth scrolling for in-page anchors (skip link included)
    $$('a[href^="#"]').forEach((link) => {
      const id = link.getAttribute('href').slice(1);
      if (!id) return;
      link.addEventListener('click', (e) => {
        const target = document.getElementById(id);
        if (!target) return;
        e.preventDefault();
        target.scrollIntoView({ behavior: reduceMotion.matches ? 'auto' : 'smooth', block: 'start' });
        if (!target.hasAttribute('tabindex')) target.setAttribute('tabindex', '-1');
        target.focus({ preventScroll: true });
        if (window.history && history.pushState) history.pushState(null, '', '#' + id);
      });
    });

    // Fallback active state if aria-current was not set in markup
    if (!$('.nav__link[aria-current="page"]')) {
      const page = location.pathname.split('/').pop() || 'index.html';
      const match = $$('.nav__link').find((a) => a.getAttribute('href') === page);
      if (match) match.setAttribute('aria-current', 'page');
    }
  }

  /* ---------- 4. Scroll reveal ---------- */
  function initReveal() {
    const items = $$('.reveal');
    if (!items.length) return;
    if (!('IntersectionObserver' in window) || reduceMotion.matches) {
      items.forEach((el) => el.classList.add('is-visible'));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) { entry.target.classList.add('is-visible'); io.unobserve(entry.target); }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    items.forEach((el, i) => { el.style.transitionDelay = `${(i % 3) * 90}ms`; io.observe(el); });
  }

  /* ---------- 5. Logo fallback ---------- */
  // If assets/logo/arvikul-logo.png has not been added yet, show the company name as text.
  function initLogo() {
    const brand = $('.brand');
    const logo = $('.brand__logo');
    if (!brand || !logo) return;
    const fallback = () => brand.classList.add('brand--no-logo');
    if (logo.complete && logo.naturalWidth === 0) fallback();
    logo.addEventListener('error', fallback);
  }

  /* ---------- 6. Forms ---------- */
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function fieldError(field) {
    const value = field.value.trim();
    if (field.required && !value) return field.tagName === 'SELECT' ? 'Please choose an option.' : 'This field is required.';
    if (field.type === 'email' && value && !EMAIL_RE.test(value)) return 'Please enter a valid email address.';
    return '';
  }

  function showError(field, message) {
    field.setAttribute('aria-invalid', message ? 'true' : 'false');
    const out = document.getElementById(`${field.id}-error`);
    if (out) out.textContent = message;
  }

  function validateField(field) {
    const message = fieldError(field);
    showError(field, message);
    return !message;
  }

  function validateForm(form) {
    let firstInvalid = null;
    $$('input, select, textarea', form).forEach((field) => {
      if (!validateField(field) && !firstInvalid) firstInvalid = field;
    });
    if (firstInvalid) firstInvalid.focus();
    return !firstInvalid;
  }

  function setStatus(form, message, type) {
    const out = document.getElementById(`${form.id}-status`);
    if (!out) return;
    out.textContent = message;
    out.classList.toggle('is-success', type === 'success');
    out.classList.toggle('is-error', type === 'error');
  }

  function attachLiveValidation(form) {
    $$('input, select, textarea', form).forEach((field) => {
      field.addEventListener('blur', () => validateField(field));
      field.addEventListener('input', () => { if (field.getAttribute('aria-invalid') === 'true') validateField(field); });
    });
  }

  function initForms() {
    $$('form[data-validate]').forEach((form) => {
      attachLiveValidation(form);
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        setStatus(form, '', '');
        if (!validateForm(form)) { setStatus(form, 'Please correct the highlighted fields.', 'error'); return; }

        const endpoint = (form.dataset.endpoint || '').trim();
        if (endpoint) {
          // A real submission endpoint was configured: send it, report only the real result.
          try {
            const res = await fetch(endpoint, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            form.reset();
            setStatus(form, 'Your message was submitted.', 'success');
          } catch (err) {
            setStatus(form, 'The message could not be submitted. Please email info@arvikultechnologies.com instead.', 'error');
          }
          return;
        }

        // No endpoint configured: open the visitor's email app with the message pre-filled.
        const lines = $$('input, select, textarea', form)
          .filter((f) => f.value.trim())
          .map((f) => `${f.dataset.label || f.name}: ${f.value.trim()}`);
        const project = form.elements.project_type ? ` – ${form.elements.project_type.value}` : '';
        const subject = encodeURIComponent((form.dataset.subject || 'Website enquiry') + project);
        const body = encodeURIComponent(lines.join('\n'));
        window.location.href = `mailto:info@arvikultechnologies.com?subject=${subject}&body=${body}`;
        setStatus(form, 'Your email app should now open with your message ready. Nothing is sent until you send it from there.', 'success');
      });
    });

    const footerForm = $('#footer-form');
    if (footerForm) {
      const input = $('#footer-email');
      footerForm.addEventListener('submit', (e) => {
        if (!validateField(input)) { e.preventDefault(); input.focus(); }
      });
      input.addEventListener('input', () => { if (input.getAttribute('aria-invalid') === 'true') validateField(input); });
    }

    // Pre-fill the contact form email when arriving from the footer form
    const prefill = new URLSearchParams(window.location.search).get('email');
    const target = $('#inq-email');
    if (prefill && target && !target.value) target.value = prefill;
  }

  /* ---------- Init ---------- */
  document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initNav();
    initScroll();
    initReveal();
    initLogo();
    initForms();
  });
})();
