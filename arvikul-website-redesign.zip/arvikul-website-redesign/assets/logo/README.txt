Place the original ArviKul Technologies logo here and name it:  arvikul-logo.png
(Use a different extension? Update the <img src> in the header of each HTML file.)
Until the file exists, the header shows the company name as text.
