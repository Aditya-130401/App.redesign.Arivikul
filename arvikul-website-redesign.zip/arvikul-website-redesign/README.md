# ArviKul Technologies – Website Frontend Redesign

Static redesign of https://arvikultechnologies.com/ using only HTML5, CSS3 and vanilla JavaScript. No frameworks, no build step, no backend.

## Folder structure

```
arvikul-website-redesign/
├── index.html        Home
├── services.html     Services
├── about.html        About
├── contact.html      Contact
├── css/
│   ├── style.css        Design tokens, 3 themes, components, motion
│   └── responsive.css   Tablet / laptop / desktop layouts, desktop nav
├── js/script.js      Themes, nav, scroll, reveal, forms
├── assets/
│   ├── images/       (optional) local copies of images
│   ├── icons/        (optional)
│   └── logo/         PUT arvikul-logo.png HERE
└── README.md
```

## Run in VS Code

1. Unzip and open the `arvikul-website-redesign` folder in VS Code (File → Open Folder).
2. **Add the logo:** save the original logo as `assets/logo/arvikul-logo.png`. Until then the header shows the company name as text.
3. Install the **Live Server** extension (Ritwick Dey), right-click `index.html` → *Open with Live Server*.
   (Double-clicking `index.html` also works.)
4. Test on mobile: open the Live Server address (e.g. `http://192.168.x.x:5500`) from a phone on the same Wi-Fi, or use Chrome DevTools → device toolbar (Ctrl+Shift+M).

## Features

- Light, Dark and Blue professional themes (header switcher, saved in `localStorage` under `arvikul-theme`)
- Responsive header with hamburger menu (Esc / outside click / link click closes it)
- Continuously scrolling feature bar (CSS only, seamless loop, pauses on hover/focus, honours `prefers-reduced-motion`)
- Scroll-reveal via `IntersectionObserver`, back-to-top button, smooth in-page scrolling, skip link, visible focus states
- Client-side form validation with accessible inline errors

## Forms – read this

The original forms are part of a hosted site-builder; their submission endpoint is not visible in the public page content, so it could not be copied.

- **Default behaviour:** after validation the form opens the visitor's email app with the message pre-filled, addressed to `info@arvikultechnologies.com`. The page never claims a message was sent.
- **To use a real endpoint:** put its URL in the form's `data-endpoint=""` attribute (e.g. Formspree, your own API). The script then POSTs the form data and shows success only if the server answers OK.
- The footer form (`Your Email Address Here` / `Start Your Journey Today`) sends the email to `contact.html`, where it pre-fills the email field.

## Images

All images are the original ones, loaded from their original hosts (`assets.zyrosite.com`, `images.unsplash.com`). To self-host, download them into `assets/images/` and update the URLs in the HTML and in the `--bg-img` / hero rules in `css/style.css`.

## Links

Navigation points to `.html` files (e.g. `services.html`). The live site uses clean URLs (`/services`). If you deploy on the same domain with clean-URL rewriting, change the four nav hrefs and the footer form action accordingly.

## Deploying

Upload the folder to any static host (Netlify, GitHub Pages, Cloudflare Pages, Hostinger). No build needed.

## Troubleshooting

- *Styles missing:* check that `css/style.css` and `css/responsive.css` exist and you opened the folder root.
- *Theme does not persist:* browsers block `localStorage` for some `file://` / private-window setups – use Live Server.
- *Images blank:* the browser must be online (images are remote).
- *Logo not showing:* filename must be exactly `assets/logo/arvikul-logo.png`.
